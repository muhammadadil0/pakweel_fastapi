from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from passlib.context import CryptContext
from django.contrib.auth import get_user_model
from django.core.mail import send_mail

app = FastAPI()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

User = get_user_model()

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

@app.post("/api/signup/")
def create_user(user: UserCreate):
    if User.objects.filter(email=user.email).exists():
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = pwd_context.hash(user.password)
    new_user = User.objects.create(username=user.username, email=user.email, password=hashed_password)
    return {"message": "User created successfully", "username": new_user.username}

@app.post("/api/login/")
def login(user: UserCreate):
    try:
        user_obj = User.objects.get(email=user.email)
        if not pwd_context.verify(user.password, user_obj.password):
            raise HTTPException(status_code=400, detail="Incorrect password")
    except User.DoesNotExist:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": f"Welcome, {user_obj.username}!"}

class PasswordResetRequest(BaseModel):
    email: str

@app.post("/api/password_reset/")
def password_reset(request: PasswordResetRequest):
    try:
        user_obj = User.objects.get(email=request.email)
        reset_link = f"http://localhost:8000/reset/{user_obj.username}"
        send_mail("Password Reset", f"Click the link to reset your password: {reset_link}", "noreply@example.com", [user_obj.email])
        return {"message": "Password reset link sent to your email!"}
    except User.DoesNotExist:
        raise HTTPException(status_code=404, detail="User not found")
