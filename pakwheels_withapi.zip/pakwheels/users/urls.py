from django.urls import path
from django.contrib.auth import views as auth_views  # Import auth_views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView  # Import JWT views
from . import views  # Import your views

urlpatterns = [
    # Register route
    path('register/', views.register, name='register'),

    # Login route using built-in LoginView
    path('login/', auth_views.LoginView.as_view(template_name='users/login.html'), name='login'),

    # Logout route
    path('logout/', views.logout_view, name='logout'),

    # Home route
    path('', views.home, name='home'),

    # Password reset routes using built-in views
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='users/password_reset.html'), name='password_reset'),
    path('password_reset_done/', auth_views.PasswordResetDoneView.as_view(template_name='users/password_reset_done.html'), name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='users/password_reset_confirm.html'), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='users/password_reset_complete.html'), name='password_reset_complete'),

    # JWT Token routes
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # Token obtain route
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # Token refresh route
]
