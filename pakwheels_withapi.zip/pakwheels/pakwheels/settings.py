from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.1/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = "django-insecure-%3*&p30&$$ewuqe5*=*c)ut)_&k&9@-8bd6f0fnq3gh)d^l-e1"

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ['*']  # Update this for production to restrict hosts

# Application definition
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    'users',  # Your app for managing users
]

# Email backend for development (use SMTP in production)
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'  # Update for production use
EMAIL_HOST = 'smtp.gmail.com'  # Example for Gmail SMTP, use a different one for production
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your_email@gmail.com'  # Your email for sending emails
EMAIL_HOST_PASSWORD = 'your_email_password'  # Your email password (use environment variables for security)

# Custom user model
AUTH_USER_MODEL = 'users.CustomUser'

# Login redirect URL after successful login
LOGIN_REDIRECT_URL = 'home'  # Change to the correct URL name for your homepage

# Middleware for request processing
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# Root URL configuration
ROOT_URLCONF = "pakwheels.urls"

# Templates configuration
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / 'users' / 'templates'],  # Make sure the templates path is correct
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# WSGI application
WSGI_APPLICATION = "pakwheels.wsgi.application"

# Database configuration (SQLite for development, change for production)
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",  # Use PostgreSQL for production
        "NAME": BASE_DIR / "db.sqlite3",  # Database location for development
    }
}

# Password validation settings
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]

# Internationalization settings
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

# Static files configuration
STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]  # Optional: add custom static files directory

# Default primary key field type
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Additional settings (optional, based on your project needs)
# STATIC_ROOT = BASE_DIR / "staticfiles"  # Uncomment for production (collectstatic will use this)
# MEDIA_URL = "/media/"
# MEDIA_ROOT = BASE_DIR / "media"
