from django.contrib import admin
from django.urls import path, include
from fastapi import FastAPI
from django.http import JsonResponse
from fastapi.middleware.wsgi import WSGIMiddleware
from django.core.wsgi import get_wsgi_application
from users import views

# Initialize FastAPI
fastapi_app = FastAPI()

# Define FastAPI routes (example: test API route)
@fastapi_app.get("/api/test")
def test_api():
    return JsonResponse({"message": "FastAPI is integrated with Django!"})

# Django WSGI Application (required for Django)
django_application = get_wsgi_application()

# Combine Django with FastAPI via WSGI middleware
application = WSGIMiddleware(fastapi_app)

# Django URL Patterns
urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.home, name='home'),  # Django view for home
    path('', views.home, name='home'),  # This line adds the root URL for home view
    path('users/', include('users.urls'))
]
