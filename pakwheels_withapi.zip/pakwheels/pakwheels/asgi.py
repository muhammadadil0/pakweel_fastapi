import os
from django.core.asgi import get_asgi_application
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.middleware.wsgi import WSGIMiddleware

# Set Django settings module
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "pakwheels.settings")

# Initialize the Django ASGI application
django_asgi_app = get_asgi_application()

# Initialize FastAPI app
fastapi_app = FastAPI()

# FastAPI route example
@fastapi_app.get("/api/")
def read_root():
    return {"message": "Hello from FastAPI!"}

# FastAPI route for testing integration
@fastapi_app.get("/api/test")
def test_api():
    return JSONResponse({"message": "FastAPI is integrated with Django!"})

# Combine both apps using WSGIMiddleware for Django and mount FastAPI under a path
application = django_asgi_app  # This keeps the Django ASGI app as the main application

# Mount FastAPI at a specific route like /fastapi
application = WSGIMiddleware(django_asgi_app)  # Keeps the Django app as the base application
fastapi_app.mount("/fastapi", fastapi_app)  # Mount FastAPI under /fastapi path
