from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import JWTError, jwt
from django.contrib.auth import get_user_model
from fastapi.responses import JSONResponse

app = FastAPI()

User = get_user_model()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

def create_access_token(data: dict, expires_delta=None):
    to_encode = data.copy()
    if expires_delta:
        to_encode.update({"exp": expires_delta})
    else:
        to_encode.update({"exp": 600})  # Default expiry in seconds
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

@app.post("/api/signup/")
def signup(user: UserCreate):
    if User.objects.filter(email=user.email).exists():
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = pwd_context.hash(user.password)
    new_user = User.objects.create(username=user.username, email=user.email, password=hashed_password)
    return {"message": "User created successfully", "username": new_user.username}

@app.post("/api/login/")
def login(user: UserLogin):
    try:
        user_obj = User.objects.get(email=user.email)
        if not pwd_context.verify(user.password, user_obj.password):
            raise HTTPException(status_code=400, detail="Incorrect password")
    except User.DoesNotExist:
        raise HTTPException(status_code=404, detail="User not found")
    
    access_token = create_access_token(data={"sub": user_obj.email})
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/api/password_reset/")
def password_reset(email: str):
    try:
        user_obj = User.objects.get(email=email)
        reset_link = f"http://localhost:8000/reset/{user_obj.username}"
        # You can implement email sending logic here
        return {"message": f"Password reset link: {reset_link}"}
    except User.DoesNotExist:
        raise HTTPException(status_code=404, detail="User not found")
